﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
   Inherits System.Windows.Forms.Form

   'Form overrides dispose to clean up the component list.
   <System.Diagnostics.DebuggerNonUserCode()> _
   Protected Overrides Sub Dispose(ByVal disposing As Boolean)
      Try
         If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
         End If
      Finally
         MyBase.Dispose(disposing)
      End Try
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> _
   Private Sub InitializeComponent()
      Me.Label1 = New System.Windows.Forms.Label()
      Me.Label2 = New System.Windows.Forms.Label()
      Me.Label3 = New System.Windows.Forms.Label()
      Me.Label4 = New System.Windows.Forms.Label()
      Me.TextBox1 = New System.Windows.Forms.TextBox()
      Me.TextBox2 = New System.Windows.Forms.TextBox()
      Me.TextBox3 = New System.Windows.Forms.TextBox()
      Me.TextBox4 = New System.Windows.Forms.TextBox()
      Me.TextBox5 = New System.Windows.Forms.TextBox()
      Me.TextBox7 = New System.Windows.Forms.TextBox()
      Me.TextBox6 = New System.Windows.Forms.TextBox()
      Me.TextBox8 = New System.Windows.Forms.TextBox()
      Me.ComboBox1 = New System.Windows.Forms.ComboBox()
      Me.TextBox9 = New System.Windows.Forms.TextBox()
      Me.TextBox10 = New System.Windows.Forms.TextBox()
      Me.TextBox11 = New System.Windows.Forms.TextBox()
      Me.TextBox12 = New System.Windows.Forms.TextBox()
      Me.TextBox13 = New System.Windows.Forms.TextBox()
      Me.TextBox14 = New System.Windows.Forms.TextBox()
      Me.TextBox15 = New System.Windows.Forms.TextBox()
      Me.TextBox16 = New System.Windows.Forms.TextBox()
      Me.Label5 = New System.Windows.Forms.Label()
      Me.Label6 = New System.Windows.Forms.Label()
      Me.Label7 = New System.Windows.Forms.Label()
      Me.Label8 = New System.Windows.Forms.Label()
      Me.Label9 = New System.Windows.Forms.Label()
      Me.Label10 = New System.Windows.Forms.Label()
      Me.Label11 = New System.Windows.Forms.Label()
      Me.Label12 = New System.Windows.Forms.Label()
      Me.Label13 = New System.Windows.Forms.Label()
      Me.Label14 = New System.Windows.Forms.Label()
      Me.Label15 = New System.Windows.Forms.Label()
      Me.Label16 = New System.Windows.Forms.Label()
      Me.Label17 = New System.Windows.Forms.Label()
      Me.Label18 = New System.Windows.Forms.Label()
      Me.SuspendLayout()
      '
      'Label1
      '
      Me.Label1.AutoSize = True
      Me.Label1.Location = New System.Drawing.Point(123, 44)
      Me.Label1.Name = "Label1"
      Me.Label1.Size = New System.Drawing.Size(108, 13)
      Me.Label1.TabIndex = 0
      Me.Label1.Text = "Employee Information"
      '
      'Label2
      '
      Me.Label2.AutoSize = True
      Me.Label2.Location = New System.Drawing.Point(12, 79)
      Me.Label2.Name = "Label2"
      Me.Label2.Size = New System.Drawing.Size(59, 13)
      Me.Label2.TabIndex = 1
      Me.Label2.Text = "STAFFNO:"
      '
      'Label3
      '
      Me.Label3.AutoSize = True
      Me.Label3.Location = New System.Drawing.Point(12, 102)
      Me.Label3.Name = "Label3"
      Me.Label3.Size = New System.Drawing.Size(47, 13)
      Me.Label3.TabIndex = 2
      Me.Label3.Text = "FNAME:"
      '
      'Label4
      '
      Me.Label4.AutoSize = True
      Me.Label4.Location = New System.Drawing.Point(12, 128)
      Me.Label4.Name = "Label4"
      Me.Label4.Size = New System.Drawing.Size(47, 13)
      Me.Label4.TabIndex = 3
      Me.Label4.Text = "LNAME:"
      '
      'TextBox1
      '
      Me.TextBox1.Location = New System.Drawing.Point(126, 76)
      Me.TextBox1.Name = "TextBox1"
      Me.TextBox1.Size = New System.Drawing.Size(187, 20)
      Me.TextBox1.TabIndex = 4
      '
      'TextBox2
      '
      Me.TextBox2.Location = New System.Drawing.Point(126, 206)
      Me.TextBox2.Name = "TextBox2"
      Me.TextBox2.Size = New System.Drawing.Size(187, 20)
      Me.TextBox2.TabIndex = 5
      '
      'TextBox3
      '
      Me.TextBox3.Location = New System.Drawing.Point(126, 180)
      Me.TextBox3.Name = "TextBox3"
      Me.TextBox3.Size = New System.Drawing.Size(187, 20)
      Me.TextBox3.TabIndex = 6
      '
      'TextBox4
      '
      Me.TextBox4.Location = New System.Drawing.Point(126, 154)
      Me.TextBox4.Name = "TextBox4"
      Me.TextBox4.Size = New System.Drawing.Size(187, 20)
      Me.TextBox4.TabIndex = 7
      '
      'TextBox5
      '
      Me.TextBox5.Location = New System.Drawing.Point(126, 128)
      Me.TextBox5.Name = "TextBox5"
      Me.TextBox5.Size = New System.Drawing.Size(187, 20)
      Me.TextBox5.TabIndex = 8
      '
      'TextBox7
      '
      Me.TextBox7.Location = New System.Drawing.Point(126, 102)
      Me.TextBox7.Name = "TextBox7"
      Me.TextBox7.Size = New System.Drawing.Size(187, 20)
      Me.TextBox7.TabIndex = 10
      '
      'TextBox6
      '
      Me.TextBox6.Location = New System.Drawing.Point(126, 232)
      Me.TextBox6.Name = "TextBox6"
      Me.TextBox6.Size = New System.Drawing.Size(187, 20)
      Me.TextBox6.TabIndex = 11
      '
      'TextBox8
      '
      Me.TextBox8.Location = New System.Drawing.Point(126, 258)
      Me.TextBox8.Name = "TextBox8"
      Me.TextBox8.Size = New System.Drawing.Size(187, 20)
      Me.TextBox8.TabIndex = 12
      '
      'ComboBox1
      '
      Me.ComboBox1.FormattingEnabled = True
      Me.ComboBox1.Location = New System.Drawing.Point(126, 284)
      Me.ComboBox1.Name = "ComboBox1"
      Me.ComboBox1.Size = New System.Drawing.Size(188, 21)
      Me.ComboBox1.TabIndex = 13
      '
      'TextBox9
      '
      Me.TextBox9.Location = New System.Drawing.Point(127, 493)
      Me.TextBox9.Name = "TextBox9"
      Me.TextBox9.Size = New System.Drawing.Size(187, 20)
      Me.TextBox9.TabIndex = 14
      '
      'TextBox10
      '
      Me.TextBox10.Location = New System.Drawing.Point(127, 467)
      Me.TextBox10.Name = "TextBox10"
      Me.TextBox10.Size = New System.Drawing.Size(187, 20)
      Me.TextBox10.TabIndex = 15
      '
      'TextBox11
      '
      Me.TextBox11.Location = New System.Drawing.Point(127, 441)
      Me.TextBox11.Name = "TextBox11"
      Me.TextBox11.Size = New System.Drawing.Size(187, 20)
      Me.TextBox11.TabIndex = 16
      '
      'TextBox12
      '
      Me.TextBox12.Location = New System.Drawing.Point(127, 415)
      Me.TextBox12.Name = "TextBox12"
      Me.TextBox12.Size = New System.Drawing.Size(187, 20)
      Me.TextBox12.TabIndex = 17
      '
      'TextBox13
      '
      Me.TextBox13.Location = New System.Drawing.Point(126, 389)
      Me.TextBox13.Name = "TextBox13"
      Me.TextBox13.Size = New System.Drawing.Size(187, 20)
      Me.TextBox13.TabIndex = 18
      '
      'TextBox14
      '
      Me.TextBox14.Location = New System.Drawing.Point(127, 363)
      Me.TextBox14.Name = "TextBox14"
      Me.TextBox14.Size = New System.Drawing.Size(187, 20)
      Me.TextBox14.TabIndex = 19
      '
      'TextBox15
      '
      Me.TextBox15.Location = New System.Drawing.Point(126, 337)
      Me.TextBox15.Name = "TextBox15"
      Me.TextBox15.Size = New System.Drawing.Size(187, 20)
      Me.TextBox15.TabIndex = 20
      '
      'TextBox16
      '
      Me.TextBox16.Location = New System.Drawing.Point(127, 311)
      Me.TextBox16.Name = "TextBox16"
      Me.TextBox16.Size = New System.Drawing.Size(187, 20)
      Me.TextBox16.TabIndex = 21
      '
      'Label5
      '
      Me.Label5.AutoSize = True
      Me.Label5.Location = New System.Drawing.Point(12, 493)
      Me.Label5.Name = "Label5"
      Me.Label5.Size = New System.Drawing.Size(73, 13)
      Me.Label5.TabIndex = 22
      Me.Label5.Text = "TYPEOFPAY:"
      '
      'Label6
      '
      Me.Label6.AutoSize = True
      Me.Label6.Location = New System.Drawing.Point(12, 467)
      Me.Label6.Name = "Label6"
      Me.Label6.Size = New System.Drawing.Size(93, 13)
      Me.Label6.TabIndex = 23
      Me.Label6.Text = "POSPERMTEMP:"
      '
      'Label7
      '
      Me.Label7.AutoSize = True
      Me.Label7.Location = New System.Drawing.Point(12, 441)
      Me.Label7.Name = "Label7"
      Me.Label7.Size = New System.Drawing.Size(73, 13)
      Me.Label7.TabIndex = 24
      Me.Label7.Text = "HRSPERWK:"
      '
      'Label8
      '
      Me.Label8.AutoSize = True
      Me.Label8.Location = New System.Drawing.Point(12, 415)
      Me.Label8.Name = "Label8"
      Me.Label8.Size = New System.Drawing.Size(86, 13)
      Me.Label8.TabIndex = 25
      Me.Label8.Text = "SALARYSCALE:"
      '
      'Label9
      '
      Me.Label9.AutoSize = True
      Me.Label9.Location = New System.Drawing.Point(12, 389)
      Me.Label9.Name = "Label9"
      Me.Label9.Size = New System.Drawing.Size(75, 13)
      Me.Label9.TabIndex = 26
      Me.Label9.Text = "CURSALARY:"
      '
      'Label10
      '
      Me.Label10.AutoSize = True
      Me.Label10.Location = New System.Drawing.Point(12, 363)
      Me.Label10.Name = "Label10"
      Me.Label10.Size = New System.Drawing.Size(61, 13)
      Me.Label10.TabIndex = 27
      Me.Label10.Text = "POSITION:"
      '
      'Label11
      '
      Me.Label11.AutoSize = True
      Me.Label11.Location = New System.Drawing.Point(12, 337)
      Me.Label11.Name = "Label11"
      Me.Label11.Size = New System.Drawing.Size(29, 13)
      Me.Label11.TabIndex = 28
      Me.Label11.Text = "NIN:"
      '
      'Label12
      '
      Me.Label12.AutoSize = True
      Me.Label12.Location = New System.Drawing.Point(12, 311)
      Me.Label12.Name = "Label12"
      Me.Label12.Size = New System.Drawing.Size(56, 13)
      Me.Label12.TabIndex = 29
      Me.Label12.Text = "GENDER:"
      '
      'Label13
      '
      Me.Label13.AutoSize = True
      Me.Label13.Location = New System.Drawing.Point(12, 284)
      Me.Label13.Name = "Label13"
      Me.Label13.Size = New System.Drawing.Size(33, 13)
      Me.Label13.TabIndex = 30
      Me.Label13.Text = "DOB;"
      '
      'Label14
      '
      Me.Label14.AutoSize = True
      Me.Label14.Location = New System.Drawing.Point(12, 258)
      Me.Label14.Name = "Label14"
      Me.Label14.Size = New System.Drawing.Size(48, 13)
      Me.Label14.TabIndex = 31
      Me.Label14.Text = "PHONE:"
      '
      'Label15
      '
      Me.Label15.AutoSize = True
      Me.Label15.Location = New System.Drawing.Point(12, 232)
      Me.Label15.Name = "Label15"
      Me.Label15.Size = New System.Drawing.Size(27, 13)
      Me.Label15.TabIndex = 32
      Me.Label15.Text = "ZIP:"
      '
      'Label16
      '
      Me.Label16.AutoSize = True
      Me.Label16.Location = New System.Drawing.Point(12, 206)
      Me.Label16.Name = "Label16"
      Me.Label16.Size = New System.Drawing.Size(45, 13)
      Me.Label16.TabIndex = 33
      Me.Label16.Text = "STATE:"
      '
      'Label17
      '
      Me.Label17.AutoSize = True
      Me.Label17.Location = New System.Drawing.Point(12, 180)
      Me.Label17.Name = "Label17"
      Me.Label17.Size = New System.Drawing.Size(34, 13)
      Me.Label17.TabIndex = 34
      Me.Label17.Text = "CITY:"
      '
      'Label18
      '
      Me.Label18.AutoSize = True
      Me.Label18.Location = New System.Drawing.Point(12, 154)
      Me.Label18.Name = "Label18"
      Me.Label18.Size = New System.Drawing.Size(53, 13)
      Me.Label18.TabIndex = 35
      Me.Label18.Text = "STREET:"
      '
      'Form1
      '
      Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
      Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
      Me.ClientSize = New System.Drawing.Size(851, 624)
      Me.Controls.Add(Me.Label18)
      Me.Controls.Add(Me.Label17)
      Me.Controls.Add(Me.Label16)
      Me.Controls.Add(Me.Label15)
      Me.Controls.Add(Me.Label14)
      Me.Controls.Add(Me.Label13)
      Me.Controls.Add(Me.Label12)
      Me.Controls.Add(Me.Label11)
      Me.Controls.Add(Me.Label10)
      Me.Controls.Add(Me.Label9)
      Me.Controls.Add(Me.Label8)
      Me.Controls.Add(Me.Label7)
      Me.Controls.Add(Me.Label6)
      Me.Controls.Add(Me.Label5)
      Me.Controls.Add(Me.TextBox16)
      Me.Controls.Add(Me.TextBox15)
      Me.Controls.Add(Me.TextBox14)
      Me.Controls.Add(Me.TextBox13)
      Me.Controls.Add(Me.TextBox12)
      Me.Controls.Add(Me.TextBox11)
      Me.Controls.Add(Me.TextBox10)
      Me.Controls.Add(Me.TextBox9)
      Me.Controls.Add(Me.ComboBox1)
      Me.Controls.Add(Me.TextBox8)
      Me.Controls.Add(Me.TextBox6)
      Me.Controls.Add(Me.TextBox7)
      Me.Controls.Add(Me.TextBox5)
      Me.Controls.Add(Me.TextBox4)
      Me.Controls.Add(Me.TextBox3)
      Me.Controls.Add(Me.TextBox2)
      Me.Controls.Add(Me.TextBox1)
      Me.Controls.Add(Me.Label4)
      Me.Controls.Add(Me.Label3)
      Me.Controls.Add(Me.Label2)
      Me.Controls.Add(Me.Label1)
      Me.Name = "Form1"
      Me.Text = "CS3630 (schultzder_sandovala)"
      Me.ResumeLayout(False)
      Me.PerformLayout()

   End Sub

   Friend WithEvents Label1 As Label
   Friend WithEvents Label2 As Label
   Friend WithEvents Label3 As Label
   Friend WithEvents Label4 As Label
   Friend WithEvents TextBox1 As TextBox
   Friend WithEvents TextBox2 As TextBox
   Friend WithEvents TextBox3 As TextBox
   Friend WithEvents TextBox4 As TextBox
   Friend WithEvents TextBox5 As TextBox
   Friend WithEvents TextBox7 As TextBox
   Friend WithEvents TextBox6 As TextBox
   Friend WithEvents TextBox8 As TextBox
   Friend WithEvents ComboBox1 As ComboBox
   Friend WithEvents TextBox9 As TextBox
   Friend WithEvents TextBox10 As TextBox
   Friend WithEvents TextBox11 As TextBox
   Friend WithEvents TextBox12 As TextBox
   Friend WithEvents TextBox13 As TextBox
   Friend WithEvents TextBox14 As TextBox
   Friend WithEvents TextBox15 As TextBox
   Friend WithEvents TextBox16 As TextBox
   Friend WithEvents Label5 As Label
   Friend WithEvents Label6 As Label
   Friend WithEvents Label7 As Label
   Friend WithEvents Label8 As Label
   Friend WithEvents Label9 As Label
   Friend WithEvents Label10 As Label
   Friend WithEvents Label11 As Label
   Friend WithEvents Label12 As Label
   Friend WithEvents Label13 As Label
   Friend WithEvents Label14 As Label
   Friend WithEvents Label15 As Label
   Friend WithEvents Label16 As Label
   Friend WithEvents Label17 As Label
   Friend WithEvents Label18 As Label
End Class
