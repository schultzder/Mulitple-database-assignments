﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Staff
   Inherits System.Windows.Forms.Form

   'Form overrides dispose to clean up the component list.
   <System.Diagnostics.DebuggerNonUserCode()> _
   Protected Overrides Sub Dispose(ByVal disposing As Boolean)
      Try
         If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
         End If
      Finally
         MyBase.Dispose(disposing)
      End Try
   End Sub

   'Required by the Windows Form Designer
   Private components As System.ComponentModel.IContainer

   'NOTE: The following procedure is required by the Windows Form Designer
   'It can be modified using the Windows Form Designer.  
   'Do not modify it using the code editor.
   <System.Diagnostics.DebuggerStepThrough()> _
   Private Sub InitializeComponent()
      Me.TextBoxFNAME = New System.Windows.Forms.TextBox()
      Me.TextBoxGENDER = New System.Windows.Forms.TextBox()
      Me.TextBoxPHONE = New System.Windows.Forms.TextBox()
      Me.TextBoxZIP = New System.Windows.Forms.TextBox()
      Me.TextBoxSTATE = New System.Windows.Forms.TextBox()
      Me.TextBoxCITY = New System.Windows.Forms.TextBox()
      Me.TextBoxSTREET = New System.Windows.Forms.TextBox()
      Me.TextBoxLNAME = New System.Windows.Forms.TextBox()
      Me.ComboBoxDOB = New System.Windows.Forms.ComboBox()
      Me.TextBoxTYPEOFPAY = New System.Windows.Forms.TextBox()
      Me.TextBoxPOSPERMTEMP = New System.Windows.Forms.TextBox()
      Me.TextBoxSTAFFNO = New System.Windows.Forms.TextBox()
      Me.TextBoxHRSPERWK = New System.Windows.Forms.TextBox()
      Me.TextBoxSALARYSCALE = New System.Windows.Forms.TextBox()
      Me.TextBoxCURSALARY = New System.Windows.Forms.TextBox()
      Me.TextBoxPOSITION = New System.Windows.Forms.TextBox()
      Me.TextBoxNIN = New System.Windows.Forms.TextBox()
      Me.Label1 = New System.Windows.Forms.Label()
      Me.Label2 = New System.Windows.Forms.Label()
      Me.Label3 = New System.Windows.Forms.Label()
      Me.Label4 = New System.Windows.Forms.Label()
      Me.Label5 = New System.Windows.Forms.Label()
      Me.Label6 = New System.Windows.Forms.Label()
      Me.Label7 = New System.Windows.Forms.Label()
      Me.Label8 = New System.Windows.Forms.Label()
      Me.Label9 = New System.Windows.Forms.Label()
      Me.Label10 = New System.Windows.Forms.Label()
      Me.Label11 = New System.Windows.Forms.Label()
      Me.Label12 = New System.Windows.Forms.Label()
      Me.Label13 = New System.Windows.Forms.Label()
      Me.Label14 = New System.Windows.Forms.Label()
      Me.Label15 = New System.Windows.Forms.Label()
      Me.Label16 = New System.Windows.Forms.Label()
      Me.Label17 = New System.Windows.Forms.Label()
      Me.Label18 = New System.Windows.Forms.Label()
      Me.ButtonStaffJumpB = New System.Windows.Forms.Button()
      Me.ButtonSAVEStaff = New System.Windows.Forms.Button()
      Me.ButtonDELETEStaff = New System.Windows.Forms.Button()
      Me.ButtonSAVEQual = New System.Windows.Forms.Button()
      Me.ButtonDELETEQual = New System.Windows.Forms.Button()
      Me.ButtonNEWQual = New System.Windows.Forms.Button()
      Me.ButtonNEWStaff = New System.Windows.Forms.Button()
      Me.ButtonPrevStaff = New System.Windows.Forms.Button()
      Me.TextBoxSTAFFcount = New System.Windows.Forms.TextBox()
      Me.ButtonNextStaff = New System.Windows.Forms.Button()
      Me.ButtonStaffJumpF = New System.Windows.Forms.Button()
      Me.Label19 = New System.Windows.Forms.Label()
      Me.Label20 = New System.Windows.Forms.Label()
      Me.Label21 = New System.Windows.Forms.Label()
      Me.Label22 = New System.Windows.Forms.Label()
      Me.ComboBoxQUALDATE = New System.Windows.Forms.ComboBox()
      Me.TextBoxTYPE = New System.Windows.Forms.TextBox()
      Me.TextBoxINSTNAME = New System.Windows.Forms.TextBox()
      Me.ButtonQualJumpFirst = New System.Windows.Forms.Button()
      Me.ButtonQualPrev = New System.Windows.Forms.Button()
      Me.TextBoxQUALcount = New System.Windows.Forms.TextBox()
      Me.ButtonQualNext = New System.Windows.Forms.Button()
      Me.ButtonQualJumpLast = New System.Windows.Forms.Button()
      Me.Label23 = New System.Windows.Forms.Label()
      Me.Label24 = New System.Windows.Forms.Label()
      Me.Label25 = New System.Windows.Forms.Label()
      Me.Label26 = New System.Windows.Forms.Label()
      Me.Label27 = New System.Windows.Forms.Label()
      Me.TextBoxORGNAME = New System.Windows.Forms.TextBox()
      Me.TextBoxWORKPOS = New System.Windows.Forms.TextBox()
      Me.TextBoxSTARTDATE = New System.Windows.Forms.TextBox()
      Me.TextBoxFINISHDATE = New System.Windows.Forms.TextBox()
      Me.ButtonWorkJumpFirst = New System.Windows.Forms.Button()
      Me.ButtonWorkPrev = New System.Windows.Forms.Button()
      Me.TextBoxWORKcount = New System.Windows.Forms.TextBox()
      Me.ButtonWorkNext = New System.Windows.Forms.Button()
      Me.ButtonWorkJumpLast = New System.Windows.Forms.Button()
      Me.ButtonNEWWork = New System.Windows.Forms.Button()
      Me.ButtonSAVEwork = New System.Windows.Forms.Button()
      Me.ButtonDELETEwork = New System.Windows.Forms.Button()
      Me.ComboBoxFIELD = New System.Windows.Forms.ComboBox()
      Me.ButtonALL = New System.Windows.Forms.Button()
      Me.ButtonSEARCH = New System.Windows.Forms.Button()
      Me.TextBoxVALUE = New System.Windows.Forms.TextBox()
      Me.Label28 = New System.Windows.Forms.Label()
      Me.Label29 = New System.Windows.Forms.Label()
      Me.Button24 = New System.Windows.Forms.Button()
      Me.SuspendLayout()
      '
      'TextBoxFNAME
      '
      Me.TextBoxFNAME.Location = New System.Drawing.Point(100, 62)
      Me.TextBoxFNAME.Name = "TextBoxFNAME"
      Me.TextBoxFNAME.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxFNAME.TabIndex = 0
      '
      'TextBoxGENDER
      '
      Me.TextBoxGENDER.Location = New System.Drawing.Point(100, 271)
      Me.TextBoxGENDER.Name = "TextBoxGENDER"
      Me.TextBoxGENDER.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxGENDER.TabIndex = 1
      '
      'TextBoxPHONE
      '
      Me.TextBoxPHONE.Location = New System.Drawing.Point(100, 218)
      Me.TextBoxPHONE.Name = "TextBoxPHONE"
      Me.TextBoxPHONE.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxPHONE.TabIndex = 2
      '
      'TextBoxZIP
      '
      Me.TextBoxZIP.Location = New System.Drawing.Point(100, 192)
      Me.TextBoxZIP.Name = "TextBoxZIP"
      Me.TextBoxZIP.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxZIP.TabIndex = 3
      '
      'TextBoxSTATE
      '
      Me.TextBoxSTATE.Location = New System.Drawing.Point(100, 166)
      Me.TextBoxSTATE.Name = "TextBoxSTATE"
      Me.TextBoxSTATE.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxSTATE.TabIndex = 4
      '
      'TextBoxCITY
      '
      Me.TextBoxCITY.Location = New System.Drawing.Point(100, 140)
      Me.TextBoxCITY.Name = "TextBoxCITY"
      Me.TextBoxCITY.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxCITY.TabIndex = 5
      '
      'TextBoxSTREET
      '
      Me.TextBoxSTREET.Location = New System.Drawing.Point(100, 111)
      Me.TextBoxSTREET.Name = "TextBoxSTREET"
      Me.TextBoxSTREET.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxSTREET.TabIndex = 6
      '
      'TextBoxLNAME
      '
      Me.TextBoxLNAME.Location = New System.Drawing.Point(100, 88)
      Me.TextBoxLNAME.Name = "TextBoxLNAME"
      Me.TextBoxLNAME.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxLNAME.TabIndex = 7
      '
      'ComboBoxDOB
      '
      Me.ComboBoxDOB.FormattingEnabled = True
      Me.ComboBoxDOB.Location = New System.Drawing.Point(100, 244)
      Me.ComboBoxDOB.Name = "ComboBoxDOB"
      Me.ComboBoxDOB.Size = New System.Drawing.Size(199, 21)
      Me.ComboBoxDOB.TabIndex = 8
      '
      'TextBoxTYPEOFPAY
      '
      Me.TextBoxTYPEOFPAY.Location = New System.Drawing.Point(100, 453)
      Me.TextBoxTYPEOFPAY.Name = "TextBoxTYPEOFPAY"
      Me.TextBoxTYPEOFPAY.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxTYPEOFPAY.TabIndex = 9
      '
      'TextBoxPOSPERMTEMP
      '
      Me.TextBoxPOSPERMTEMP.Location = New System.Drawing.Point(100, 427)
      Me.TextBoxPOSPERMTEMP.Name = "TextBoxPOSPERMTEMP"
      Me.TextBoxPOSPERMTEMP.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxPOSPERMTEMP.TabIndex = 10
      '
      'TextBoxSTAFFNO
      '
      Me.TextBoxSTAFFNO.Location = New System.Drawing.Point(100, 36)
      Me.TextBoxSTAFFNO.Name = "TextBoxSTAFFNO"
      Me.TextBoxSTAFFNO.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxSTAFFNO.TabIndex = 11
      '
      'TextBoxHRSPERWK
      '
      Me.TextBoxHRSPERWK.Location = New System.Drawing.Point(100, 401)
      Me.TextBoxHRSPERWK.Name = "TextBoxHRSPERWK"
      Me.TextBoxHRSPERWK.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxHRSPERWK.TabIndex = 12
      '
      'TextBoxSALARYSCALE
      '
      Me.TextBoxSALARYSCALE.Location = New System.Drawing.Point(100, 375)
      Me.TextBoxSALARYSCALE.Name = "TextBoxSALARYSCALE"
      Me.TextBoxSALARYSCALE.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxSALARYSCALE.TabIndex = 13
      '
      'TextBoxCURSALARY
      '
      Me.TextBoxCURSALARY.Location = New System.Drawing.Point(100, 349)
      Me.TextBoxCURSALARY.Name = "TextBoxCURSALARY"
      Me.TextBoxCURSALARY.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxCURSALARY.TabIndex = 14
      '
      'TextBoxPOSITION
      '
      Me.TextBoxPOSITION.Location = New System.Drawing.Point(100, 323)
      Me.TextBoxPOSITION.Name = "TextBoxPOSITION"
      Me.TextBoxPOSITION.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxPOSITION.TabIndex = 15
      '
      'TextBoxNIN
      '
      Me.TextBoxNIN.Location = New System.Drawing.Point(100, 297)
      Me.TextBoxNIN.Name = "TextBoxNIN"
      Me.TextBoxNIN.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxNIN.TabIndex = 16
      '
      'Label1
      '
      Me.Label1.AutoSize = True
      Me.Label1.Location = New System.Drawing.Point(97, 9)
      Me.Label1.Name = "Label1"
      Me.Label1.Size = New System.Drawing.Size(108, 13)
      Me.Label1.TabIndex = 17
      Me.Label1.Text = "Employee Information"
      '
      'Label2
      '
      Me.Label2.AutoSize = True
      Me.Label2.Location = New System.Drawing.Point(1, 39)
      Me.Label2.Name = "Label2"
      Me.Label2.Size = New System.Drawing.Size(59, 13)
      Me.Label2.TabIndex = 18
      Me.Label2.Text = "STAFFNO:"
      '
      'Label3
      '
      Me.Label3.AutoSize = True
      Me.Label3.Location = New System.Drawing.Point(1, 404)
      Me.Label3.Name = "Label3"
      Me.Label3.Size = New System.Drawing.Size(73, 13)
      Me.Label3.TabIndex = 19
      Me.Label3.Text = "HRSPERWK:"
      '
      'Label4
      '
      Me.Label4.AutoSize = True
      Me.Label4.Location = New System.Drawing.Point(1, 378)
      Me.Label4.Name = "Label4"
      Me.Label4.Size = New System.Drawing.Size(86, 13)
      Me.Label4.TabIndex = 20
      Me.Label4.Text = "SALARYSCALE:"
      '
      'Label5
      '
      Me.Label5.AutoSize = True
      Me.Label5.Location = New System.Drawing.Point(1, 352)
      Me.Label5.Name = "Label5"
      Me.Label5.Size = New System.Drawing.Size(75, 13)
      Me.Label5.TabIndex = 21
      Me.Label5.Text = "CURSALARY:"
      '
      'Label6
      '
      Me.Label6.AutoSize = True
      Me.Label6.Location = New System.Drawing.Point(1, 323)
      Me.Label6.Name = "Label6"
      Me.Label6.Size = New System.Drawing.Size(61, 13)
      Me.Label6.TabIndex = 22
      Me.Label6.Text = "POSITION:"
      '
      'Label7
      '
      Me.Label7.AutoSize = True
      Me.Label7.Location = New System.Drawing.Point(1, 297)
      Me.Label7.Name = "Label7"
      Me.Label7.Size = New System.Drawing.Size(29, 13)
      Me.Label7.TabIndex = 23
      Me.Label7.Text = "NIN:"
      '
      'Label8
      '
      Me.Label8.AutoSize = True
      Me.Label8.Location = New System.Drawing.Point(1, 270)
      Me.Label8.Name = "Label8"
      Me.Label8.Size = New System.Drawing.Size(56, 13)
      Me.Label8.TabIndex = 24
      Me.Label8.Text = "GENDER:"
      '
      'Label9
      '
      Me.Label9.AutoSize = True
      Me.Label9.Location = New System.Drawing.Point(1, 244)
      Me.Label9.Name = "Label9"
      Me.Label9.Size = New System.Drawing.Size(33, 13)
      Me.Label9.TabIndex = 25
      Me.Label9.Text = "DOB:"
      '
      'Label10
      '
      Me.Label10.AutoSize = True
      Me.Label10.Location = New System.Drawing.Point(1, 218)
      Me.Label10.Name = "Label10"
      Me.Label10.Size = New System.Drawing.Size(48, 13)
      Me.Label10.TabIndex = 26
      Me.Label10.Text = "PHONE:"
      '
      'Label11
      '
      Me.Label11.AutoSize = True
      Me.Label11.Location = New System.Drawing.Point(1, 195)
      Me.Label11.Name = "Label11"
      Me.Label11.Size = New System.Drawing.Size(27, 13)
      Me.Label11.TabIndex = 27
      Me.Label11.Text = "ZIP:"
      '
      'Label12
      '
      Me.Label12.AutoSize = True
      Me.Label12.Location = New System.Drawing.Point(1, 166)
      Me.Label12.Name = "Label12"
      Me.Label12.Size = New System.Drawing.Size(45, 13)
      Me.Label12.TabIndex = 28
      Me.Label12.Text = "STATE:"
      '
      'Label13
      '
      Me.Label13.AutoSize = True
      Me.Label13.Location = New System.Drawing.Point(1, 140)
      Me.Label13.Name = "Label13"
      Me.Label13.Size = New System.Drawing.Size(34, 13)
      Me.Label13.TabIndex = 29
      Me.Label13.Text = "CITY:"
      '
      'Label14
      '
      Me.Label14.AutoSize = True
      Me.Label14.Location = New System.Drawing.Point(1, 114)
      Me.Label14.Name = "Label14"
      Me.Label14.Size = New System.Drawing.Size(53, 13)
      Me.Label14.TabIndex = 30
      Me.Label14.Text = "STREET:"
      '
      'Label15
      '
      Me.Label15.AutoSize = True
      Me.Label15.Location = New System.Drawing.Point(1, 91)
      Me.Label15.Name = "Label15"
      Me.Label15.Size = New System.Drawing.Size(47, 13)
      Me.Label15.TabIndex = 31
      Me.Label15.Text = "&LNAME:"
      '
      'Label16
      '
      Me.Label16.AutoSize = True
      Me.Label16.Location = New System.Drawing.Point(1, 65)
      Me.Label16.Name = "Label16"
      Me.Label16.Size = New System.Drawing.Size(47, 13)
      Me.Label16.TabIndex = 32
      Me.Label16.Text = "FNAME:"
      '
      'Label17
      '
      Me.Label17.AutoSize = True
      Me.Label17.Location = New System.Drawing.Point(1, 456)
      Me.Label17.Name = "Label17"
      Me.Label17.Size = New System.Drawing.Size(73, 13)
      Me.Label17.TabIndex = 33
      Me.Label17.Text = "TYPEOFPAY:"
      '
      'Label18
      '
      Me.Label18.AutoSize = True
      Me.Label18.Location = New System.Drawing.Point(1, 430)
      Me.Label18.Name = "Label18"
      Me.Label18.Size = New System.Drawing.Size(93, 13)
      Me.Label18.TabIndex = 34
      Me.Label18.Text = "POSPERMTEMP:"
      '
      'ButtonStaffJumpB
      '
      Me.ButtonStaffJumpB.Location = New System.Drawing.Point(81, 495)
      Me.ButtonStaffJumpB.Name = "ButtonStaffJumpB"
      Me.ButtonStaffJumpB.Size = New System.Drawing.Size(38, 23)
      Me.ButtonStaffJumpB.TabIndex = 35
      Me.ButtonStaffJumpB.Text = "|<"
      Me.ButtonStaffJumpB.UseVisualStyleBackColor = True
      '
      'ButtonSAVEStaff
      '
      Me.ButtonSAVEStaff.Location = New System.Drawing.Point(162, 534)
      Me.ButtonSAVEStaff.Name = "ButtonSAVEStaff"
      Me.ButtonSAVEStaff.Size = New System.Drawing.Size(75, 23)
      Me.ButtonSAVEStaff.TabIndex = 36
      Me.ButtonSAVEStaff.Text = "Save"
      Me.ButtonSAVEStaff.UseVisualStyleBackColor = True
      '
      'ButtonDELETEStaff
      '
      Me.ButtonDELETEStaff.Location = New System.Drawing.Point(243, 534)
      Me.ButtonDELETEStaff.Name = "ButtonDELETEStaff"
      Me.ButtonDELETEStaff.Size = New System.Drawing.Size(75, 23)
      Me.ButtonDELETEStaff.TabIndex = 37
      Me.ButtonDELETEStaff.Text = "Delete"
      Me.ButtonDELETEStaff.UseVisualStyleBackColor = True
      '
      'ButtonSAVEQual
      '
      Me.ButtonSAVEQual.Location = New System.Drawing.Point(595, 166)
      Me.ButtonSAVEQual.Name = "ButtonSAVEQual"
      Me.ButtonSAVEQual.Size = New System.Drawing.Size(75, 23)
      Me.ButtonSAVEQual.TabIndex = 38
      Me.ButtonSAVEQual.Text = "Save"
      Me.ButtonSAVEQual.UseVisualStyleBackColor = True
      '
      'ButtonDELETEQual
      '
      Me.ButtonDELETEQual.Location = New System.Drawing.Point(676, 166)
      Me.ButtonDELETEQual.Name = "ButtonDELETEQual"
      Me.ButtonDELETEQual.Size = New System.Drawing.Size(75, 23)
      Me.ButtonDELETEQual.TabIndex = 39
      Me.ButtonDELETEQual.Text = "Delete"
      Me.ButtonDELETEQual.UseVisualStyleBackColor = True
      '
      'ButtonNEWQual
      '
      Me.ButtonNEWQual.Location = New System.Drawing.Point(514, 166)
      Me.ButtonNEWQual.Name = "ButtonNEWQual"
      Me.ButtonNEWQual.Size = New System.Drawing.Size(75, 23)
      Me.ButtonNEWQual.TabIndex = 40
      Me.ButtonNEWQual.Text = "New"
      Me.ButtonNEWQual.UseVisualStyleBackColor = True
      '
      'ButtonNEWStaff
      '
      Me.ButtonNEWStaff.Location = New System.Drawing.Point(81, 534)
      Me.ButtonNEWStaff.Name = "ButtonNEWStaff"
      Me.ButtonNEWStaff.Size = New System.Drawing.Size(75, 23)
      Me.ButtonNEWStaff.TabIndex = 41
      Me.ButtonNEWStaff.Text = "New"
      Me.ButtonNEWStaff.UseVisualStyleBackColor = True
      '
      'ButtonPrevStaff
      '
      Me.ButtonPrevStaff.Location = New System.Drawing.Point(125, 495)
      Me.ButtonPrevStaff.Name = "ButtonPrevStaff"
      Me.ButtonPrevStaff.Size = New System.Drawing.Size(38, 23)
      Me.ButtonPrevStaff.TabIndex = 42
      Me.ButtonPrevStaff.Text = "<"
      Me.ButtonPrevStaff.UseVisualStyleBackColor = True
      '
      'TextBoxSTAFFcount
      '
      Me.TextBoxSTAFFcount.Location = New System.Drawing.Point(169, 498)
      Me.TextBoxSTAFFcount.Name = "TextBoxSTAFFcount"
      Me.TextBoxSTAFFcount.Size = New System.Drawing.Size(55, 20)
      Me.TextBoxSTAFFcount.TabIndex = 43
      '
      'ButtonNextStaff
      '
      Me.ButtonNextStaff.Location = New System.Drawing.Point(230, 495)
      Me.ButtonNextStaff.Name = "ButtonNextStaff"
      Me.ButtonNextStaff.Size = New System.Drawing.Size(38, 23)
      Me.ButtonNextStaff.TabIndex = 44
      Me.ButtonNextStaff.Text = ">"
      Me.ButtonNextStaff.UseVisualStyleBackColor = True
      '
      'ButtonStaffJumpF
      '
      Me.ButtonStaffJumpF.Location = New System.Drawing.Point(274, 496)
      Me.ButtonStaffJumpF.Name = "ButtonStaffJumpF"
      Me.ButtonStaffJumpF.Size = New System.Drawing.Size(38, 23)
      Me.ButtonStaffJumpF.TabIndex = 45
      Me.ButtonStaffJumpF.Text = ">|"
      Me.ButtonStaffJumpF.UseVisualStyleBackColor = True
      '
      'Label19
      '
      Me.Label19.AutoSize = True
      Me.Label19.Location = New System.Drawing.Point(571, 9)
      Me.Label19.Name = "Label19"
      Me.Label19.Size = New System.Drawing.Size(70, 13)
      Me.Label19.TabIndex = 46
      Me.Label19.Text = "Qualifications"
      '
      'Label20
      '
      Me.Label20.AutoSize = True
      Me.Label20.Location = New System.Drawing.Point(504, 42)
      Me.Label20.Name = "Label20"
      Me.Label20.Size = New System.Drawing.Size(68, 13)
      Me.Label20.TabIndex = 47
      Me.Label20.Text = "QUALDATE:"
      '
      'Label21
      '
      Me.Label21.AutoSize = True
      Me.Label21.Location = New System.Drawing.Point(504, 69)
      Me.Label21.Name = "Label21"
      Me.Label21.Size = New System.Drawing.Size(38, 13)
      Me.Label21.TabIndex = 48
      Me.Label21.Text = "TYPE:"
      '
      'Label22
      '
      Me.Label22.AutoSize = True
      Me.Label22.Location = New System.Drawing.Point(504, 95)
      Me.Label22.Name = "Label22"
      Me.Label22.Size = New System.Drawing.Size(66, 13)
      Me.Label22.TabIndex = 49
      Me.Label22.Text = "INSTNAME:"
      '
      'ComboBoxQUALDATE
      '
      Me.ComboBoxQUALDATE.FormattingEnabled = True
      Me.ComboBoxQUALDATE.Location = New System.Drawing.Point(574, 39)
      Me.ComboBoxQUALDATE.Name = "ComboBoxQUALDATE"
      Me.ComboBoxQUALDATE.Size = New System.Drawing.Size(199, 21)
      Me.ComboBoxQUALDATE.TabIndex = 50
      '
      'TextBoxTYPE
      '
      Me.TextBoxTYPE.Location = New System.Drawing.Point(574, 66)
      Me.TextBoxTYPE.Name = "TextBoxTYPE"
      Me.TextBoxTYPE.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxTYPE.TabIndex = 51
      '
      'TextBoxINSTNAME
      '
      Me.TextBoxINSTNAME.Location = New System.Drawing.Point(574, 92)
      Me.TextBoxINSTNAME.Name = "TextBoxINSTNAME"
      Me.TextBoxINSTNAME.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxINSTNAME.TabIndex = 52
      '
      'ButtonQualJumpFirst
      '
      Me.ButtonQualJumpFirst.Location = New System.Drawing.Point(507, 130)
      Me.ButtonQualJumpFirst.Name = "ButtonQualJumpFirst"
      Me.ButtonQualJumpFirst.Size = New System.Drawing.Size(38, 23)
      Me.ButtonQualJumpFirst.TabIndex = 53
      Me.ButtonQualJumpFirst.Text = "|<"
      Me.ButtonQualJumpFirst.UseVisualStyleBackColor = True
      '
      'ButtonQualPrev
      '
      Me.ButtonQualPrev.Location = New System.Drawing.Point(551, 130)
      Me.ButtonQualPrev.Name = "ButtonQualPrev"
      Me.ButtonQualPrev.Size = New System.Drawing.Size(38, 23)
      Me.ButtonQualPrev.TabIndex = 54
      Me.ButtonQualPrev.Text = "<"
      Me.ButtonQualPrev.UseVisualStyleBackColor = True
      '
      'TextBoxQUALcount
      '
      Me.TextBoxQUALcount.Location = New System.Drawing.Point(595, 132)
      Me.TextBoxQUALcount.Name = "TextBoxQUALcount"
      Me.TextBoxQUALcount.Size = New System.Drawing.Size(55, 20)
      Me.TextBoxQUALcount.TabIndex = 55
      '
      'ButtonQualNext
      '
      Me.ButtonQualNext.Location = New System.Drawing.Point(656, 129)
      Me.ButtonQualNext.Name = "ButtonQualNext"
      Me.ButtonQualNext.Size = New System.Drawing.Size(38, 23)
      Me.ButtonQualNext.TabIndex = 56
      Me.ButtonQualNext.Text = ">"
      Me.ButtonQualNext.UseVisualStyleBackColor = True
      '
      'ButtonQualJumpLast
      '
      Me.ButtonQualJumpLast.Location = New System.Drawing.Point(700, 129)
      Me.ButtonQualJumpLast.Name = "ButtonQualJumpLast"
      Me.ButtonQualJumpLast.Size = New System.Drawing.Size(38, 23)
      Me.ButtonQualJumpLast.TabIndex = 57
      Me.ButtonQualJumpLast.Text = ">|"
      Me.ButtonQualJumpLast.UseVisualStyleBackColor = True
      '
      'Label23
      '
      Me.Label23.AutoSize = True
      Me.Label23.Location = New System.Drawing.Point(571, 270)
      Me.Label23.Name = "Label23"
      Me.Label23.Size = New System.Drawing.Size(83, 13)
      Me.Label23.TabIndex = 58
      Me.Label23.Text = "Work Experince"
      '
      'Label24
      '
      Me.Label24.AutoSize = True
      Me.Label24.Location = New System.Drawing.Point(504, 304)
      Me.Label24.Name = "Label24"
      Me.Label24.Size = New System.Drawing.Size(65, 13)
      Me.Label24.TabIndex = 59
      Me.Label24.Text = "ORGNAME:"
      '
      'Label25
      '
      Me.Label25.AutoSize = True
      Me.Label25.Location = New System.Drawing.Point(504, 330)
      Me.Label25.Name = "Label25"
      Me.Label25.Size = New System.Drawing.Size(61, 13)
      Me.Label25.TabIndex = 60
      Me.Label25.Text = "POSITION:"
      '
      'Label26
      '
      Me.Label26.AutoSize = True
      Me.Label26.Location = New System.Drawing.Point(504, 356)
      Me.Label26.Name = "Label26"
      Me.Label26.Size = New System.Drawing.Size(75, 13)
      Me.Label26.TabIndex = 61
      Me.Label26.Text = "STARTDATE:"
      '
      'Label27
      '
      Me.Label27.AutoSize = True
      Me.Label27.Location = New System.Drawing.Point(504, 382)
      Me.Label27.Name = "Label27"
      Me.Label27.Size = New System.Drawing.Size(74, 13)
      Me.Label27.TabIndex = 62
      Me.Label27.Text = "FINISHDATE:"
      '
      'TextBoxORGNAME
      '
      Me.TextBoxORGNAME.Location = New System.Drawing.Point(578, 301)
      Me.TextBoxORGNAME.Name = "TextBoxORGNAME"
      Me.TextBoxORGNAME.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxORGNAME.TabIndex = 63
      '
      'TextBoxWORKPOS
      '
      Me.TextBoxWORKPOS.Location = New System.Drawing.Point(578, 330)
      Me.TextBoxWORKPOS.Name = "TextBoxWORKPOS"
      Me.TextBoxWORKPOS.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxWORKPOS.TabIndex = 64
      '
      'TextBoxSTARTDATE
      '
      Me.TextBoxSTARTDATE.Location = New System.Drawing.Point(578, 356)
      Me.TextBoxSTARTDATE.Name = "TextBoxSTARTDATE"
      Me.TextBoxSTARTDATE.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxSTARTDATE.TabIndex = 65
      '
      'TextBoxFINISHDATE
      '
      Me.TextBoxFINISHDATE.Location = New System.Drawing.Point(578, 382)
      Me.TextBoxFINISHDATE.Name = "TextBoxFINISHDATE"
      Me.TextBoxFINISHDATE.Size = New System.Drawing.Size(199, 20)
      Me.TextBoxFINISHDATE.TabIndex = 66
      '
      'ButtonWorkJumpFirst
      '
      Me.ButtonWorkJumpFirst.Location = New System.Drawing.Point(507, 420)
      Me.ButtonWorkJumpFirst.Name = "ButtonWorkJumpFirst"
      Me.ButtonWorkJumpFirst.Size = New System.Drawing.Size(38, 23)
      Me.ButtonWorkJumpFirst.TabIndex = 67
      Me.ButtonWorkJumpFirst.Text = "|<"
      Me.ButtonWorkJumpFirst.UseVisualStyleBackColor = True
      '
      'ButtonWorkPrev
      '
      Me.ButtonWorkPrev.Location = New System.Drawing.Point(551, 420)
      Me.ButtonWorkPrev.Name = "ButtonWorkPrev"
      Me.ButtonWorkPrev.Size = New System.Drawing.Size(38, 23)
      Me.ButtonWorkPrev.TabIndex = 68
      Me.ButtonWorkPrev.Text = "<"
      Me.ButtonWorkPrev.UseVisualStyleBackColor = True
      '
      'TextBoxWORKcount
      '
      Me.TextBoxWORKcount.Location = New System.Drawing.Point(595, 422)
      Me.TextBoxWORKcount.Name = "TextBoxWORKcount"
      Me.TextBoxWORKcount.Size = New System.Drawing.Size(55, 20)
      Me.TextBoxWORKcount.TabIndex = 69
      '
      'ButtonWorkNext
      '
      Me.ButtonWorkNext.Location = New System.Drawing.Point(656, 420)
      Me.ButtonWorkNext.Name = "ButtonWorkNext"
      Me.ButtonWorkNext.Size = New System.Drawing.Size(38, 23)
      Me.ButtonWorkNext.TabIndex = 70
      Me.ButtonWorkNext.Text = ">"
      Me.ButtonWorkNext.UseVisualStyleBackColor = True
      '
      'ButtonWorkJumpLast
      '
      Me.ButtonWorkJumpLast.Location = New System.Drawing.Point(700, 419)
      Me.ButtonWorkJumpLast.Name = "ButtonWorkJumpLast"
      Me.ButtonWorkJumpLast.Size = New System.Drawing.Size(38, 23)
      Me.ButtonWorkJumpLast.TabIndex = 71
      Me.ButtonWorkJumpLast.Text = ">|"
      Me.ButtonWorkJumpLast.UseVisualStyleBackColor = True
      '
      'ButtonNEWWork
      '
      Me.ButtonNEWWork.Location = New System.Drawing.Point(514, 456)
      Me.ButtonNEWWork.Name = "ButtonNEWWork"
      Me.ButtonNEWWork.Size = New System.Drawing.Size(75, 23)
      Me.ButtonNEWWork.TabIndex = 72
      Me.ButtonNEWWork.Text = "New"
      Me.ButtonNEWWork.UseVisualStyleBackColor = True
      '
      'ButtonSAVEwork
      '
      Me.ButtonSAVEwork.Location = New System.Drawing.Point(595, 456)
      Me.ButtonSAVEwork.Name = "ButtonSAVEwork"
      Me.ButtonSAVEwork.Size = New System.Drawing.Size(75, 23)
      Me.ButtonSAVEwork.TabIndex = 73
      Me.ButtonSAVEwork.Text = "Save"
      Me.ButtonSAVEwork.UseVisualStyleBackColor = True
      '
      'ButtonDELETEwork
      '
      Me.ButtonDELETEwork.Location = New System.Drawing.Point(676, 456)
      Me.ButtonDELETEwork.Name = "ButtonDELETEwork"
      Me.ButtonDELETEwork.Size = New System.Drawing.Size(75, 23)
      Me.ButtonDELETEwork.TabIndex = 74
      Me.ButtonDELETEwork.Text = "Delete"
      Me.ButtonDELETEwork.UseVisualStyleBackColor = True
      '
      'ComboBoxFIELD
      '
      Me.ComboBoxFIELD.FormattingEnabled = True
      Me.ComboBoxFIELD.Location = New System.Drawing.Point(495, 515)
      Me.ComboBoxFIELD.Name = "ComboBoxFIELD"
      Me.ComboBoxFIELD.Size = New System.Drawing.Size(146, 21)
      Me.ComboBoxFIELD.TabIndex = 75
      '
      'ButtonALL
      '
      Me.ButtonALL.Location = New System.Drawing.Point(676, 515)
      Me.ButtonALL.Name = "ButtonALL"
      Me.ButtonALL.Size = New System.Drawing.Size(75, 23)
      Me.ButtonALL.TabIndex = 76
      Me.ButtonALL.Text = "All"
      Me.ButtonALL.UseVisualStyleBackColor = True
      '
      'ButtonSEARCH
      '
      Me.ButtonSEARCH.Location = New System.Drawing.Point(676, 544)
      Me.ButtonSEARCH.Name = "ButtonSEARCH"
      Me.ButtonSEARCH.Size = New System.Drawing.Size(75, 23)
      Me.ButtonSEARCH.TabIndex = 77
      Me.ButtonSEARCH.Text = "Search"
      Me.ButtonSEARCH.UseVisualStyleBackColor = True
      '
      'TextBoxVALUE
      '
      Me.TextBoxVALUE.Location = New System.Drawing.Point(495, 547)
      Me.TextBoxVALUE.Name = "TextBoxVALUE"
      Me.TextBoxVALUE.Size = New System.Drawing.Size(146, 20)
      Me.TextBoxVALUE.TabIndex = 78
      '
      'Label28
      '
      Me.Label28.AutoSize = True
      Me.Label28.Location = New System.Drawing.Point(415, 518)
      Me.Label28.Name = "Label28"
      Me.Label28.Size = New System.Drawing.Size(29, 13)
      Me.Label28.TabIndex = 79
      Me.Label28.Text = "Field"
      '
      'Label29
      '
      Me.Label29.AutoSize = True
      Me.Label29.Location = New System.Drawing.Point(415, 550)
      Me.Label29.Name = "Label29"
      Me.Label29.Size = New System.Drawing.Size(34, 13)
      Me.Label29.TabIndex = 80
      Me.Label29.Text = "Value"
      '
      'Button24
      '
      Me.Button24.Location = New System.Drawing.Point(369, 614)
      Me.Button24.Name = "Button24"
      Me.Button24.Size = New System.Drawing.Size(75, 23)
      Me.Button24.TabIndex = 81
      Me.Button24.Text = "Exit"
      Me.Button24.UseVisualStyleBackColor = True
      '
      'Staff
      '
      Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
      Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
      Me.ClientSize = New System.Drawing.Size(898, 649)
      Me.Controls.Add(Me.Button24)
      Me.Controls.Add(Me.Label29)
      Me.Controls.Add(Me.Label28)
      Me.Controls.Add(Me.TextBoxVALUE)
      Me.Controls.Add(Me.ButtonSEARCH)
      Me.Controls.Add(Me.ButtonALL)
      Me.Controls.Add(Me.ComboBoxFIELD)
      Me.Controls.Add(Me.ButtonDELETEwork)
      Me.Controls.Add(Me.ButtonSAVEwork)
      Me.Controls.Add(Me.ButtonNEWWork)
      Me.Controls.Add(Me.ButtonWorkJumpLast)
      Me.Controls.Add(Me.ButtonWorkNext)
      Me.Controls.Add(Me.TextBoxWORKcount)
      Me.Controls.Add(Me.ButtonWorkPrev)
      Me.Controls.Add(Me.ButtonWorkJumpFirst)
      Me.Controls.Add(Me.TextBoxFINISHDATE)
      Me.Controls.Add(Me.TextBoxSTARTDATE)
      Me.Controls.Add(Me.TextBoxWORKPOS)
      Me.Controls.Add(Me.TextBoxORGNAME)
      Me.Controls.Add(Me.Label27)
      Me.Controls.Add(Me.Label26)
      Me.Controls.Add(Me.Label25)
      Me.Controls.Add(Me.Label24)
      Me.Controls.Add(Me.Label23)
      Me.Controls.Add(Me.ButtonQualJumpLast)
      Me.Controls.Add(Me.ButtonQualNext)
      Me.Controls.Add(Me.TextBoxQUALcount)
      Me.Controls.Add(Me.ButtonQualPrev)
      Me.Controls.Add(Me.ButtonQualJumpFirst)
      Me.Controls.Add(Me.TextBoxINSTNAME)
      Me.Controls.Add(Me.TextBoxTYPE)
      Me.Controls.Add(Me.ComboBoxQUALDATE)
      Me.Controls.Add(Me.Label22)
      Me.Controls.Add(Me.Label21)
      Me.Controls.Add(Me.Label20)
      Me.Controls.Add(Me.Label19)
      Me.Controls.Add(Me.ButtonStaffJumpF)
      Me.Controls.Add(Me.ButtonNextStaff)
      Me.Controls.Add(Me.TextBoxSTAFFcount)
      Me.Controls.Add(Me.ButtonPrevStaff)
      Me.Controls.Add(Me.ButtonNEWStaff)
      Me.Controls.Add(Me.ButtonNEWQual)
      Me.Controls.Add(Me.ButtonDELETEQual)
      Me.Controls.Add(Me.ButtonSAVEQual)
      Me.Controls.Add(Me.ButtonDELETEStaff)
      Me.Controls.Add(Me.ButtonSAVEStaff)
      Me.Controls.Add(Me.ButtonStaffJumpB)
      Me.Controls.Add(Me.Label18)
      Me.Controls.Add(Me.Label17)
      Me.Controls.Add(Me.Label16)
      Me.Controls.Add(Me.Label15)
      Me.Controls.Add(Me.Label14)
      Me.Controls.Add(Me.Label13)
      Me.Controls.Add(Me.Label12)
      Me.Controls.Add(Me.Label11)
      Me.Controls.Add(Me.Label10)
      Me.Controls.Add(Me.Label9)
      Me.Controls.Add(Me.Label8)
      Me.Controls.Add(Me.Label7)
      Me.Controls.Add(Me.Label6)
      Me.Controls.Add(Me.Label5)
      Me.Controls.Add(Me.Label4)
      Me.Controls.Add(Me.Label3)
      Me.Controls.Add(Me.Label2)
      Me.Controls.Add(Me.Label1)
      Me.Controls.Add(Me.TextBoxNIN)
      Me.Controls.Add(Me.TextBoxPOSITION)
      Me.Controls.Add(Me.TextBoxCURSALARY)
      Me.Controls.Add(Me.TextBoxSALARYSCALE)
      Me.Controls.Add(Me.TextBoxHRSPERWK)
      Me.Controls.Add(Me.TextBoxSTAFFNO)
      Me.Controls.Add(Me.TextBoxPOSPERMTEMP)
      Me.Controls.Add(Me.TextBoxTYPEOFPAY)
      Me.Controls.Add(Me.ComboBoxDOB)
      Me.Controls.Add(Me.TextBoxLNAME)
      Me.Controls.Add(Me.TextBoxSTREET)
      Me.Controls.Add(Me.TextBoxCITY)
      Me.Controls.Add(Me.TextBoxSTATE)
      Me.Controls.Add(Me.TextBoxZIP)
      Me.Controls.Add(Me.TextBoxPHONE)
      Me.Controls.Add(Me.TextBoxGENDER)
      Me.Controls.Add(Me.TextBoxFNAME)
      Me.Name = "Staff"
      Me.Text = "CS3630(Derek/Andre)"
      Me.ResumeLayout(False)
      Me.PerformLayout()

   End Sub

   Friend WithEvents TextBoxFNAME As TextBox
   Friend WithEvents TextBoxGENDER As TextBox
   Friend WithEvents TextBoxPHONE As TextBox
   Friend WithEvents TextBoxZIP As TextBox
   Friend WithEvents TextBoxSTATE As TextBox
   Friend WithEvents TextBoxCITY As TextBox
   Friend WithEvents TextBoxSTREET As TextBox
   Friend WithEvents TextBoxLNAME As TextBox
   Friend WithEvents ComboBoxDOB As ComboBox
   Friend WithEvents TextBoxTYPEOFPAY As TextBox
   Friend WithEvents TextBoxPOSPERMTEMP As TextBox
   Friend WithEvents TextBoxSTAFFNO As TextBox
   Friend WithEvents TextBoxHRSPERWK As TextBox
   Friend WithEvents TextBoxSALARYSCALE As TextBox
   Friend WithEvents TextBoxCURSALARY As TextBox
   Friend WithEvents TextBoxPOSITION As TextBox
   Friend WithEvents TextBoxNIN As TextBox
   Friend WithEvents Label1 As Label
   Friend WithEvents Label2 As Label
   Friend WithEvents Label3 As Label
   Friend WithEvents Label4 As Label
   Friend WithEvents Label5 As Label
   Friend WithEvents Label6 As Label
   Friend WithEvents Label7 As Label
   Friend WithEvents Label8 As Label
   Friend WithEvents Label9 As Label
   Friend WithEvents Label10 As Label
   Friend WithEvents Label11 As Label
   Friend WithEvents Label12 As Label
   Friend WithEvents Label13 As Label
   Friend WithEvents Label14 As Label
   Friend WithEvents Label15 As Label
   Friend WithEvents Label16 As Label
   Friend WithEvents Label17 As Label
   Friend WithEvents Label18 As Label
   Friend WithEvents ButtonStaffJumpB As Button
   Friend WithEvents ButtonSAVEStaff As Button
   Friend WithEvents ButtonDELETEStaff As Button
   Friend WithEvents ButtonSAVEQual As Button
   Friend WithEvents ButtonDELETEQual As Button
   Friend WithEvents ButtonNEWQual As Button
   Friend WithEvents ButtonNEWStaff As Button
   Friend WithEvents ButtonPrevStaff As Button
   Friend WithEvents TextBoxSTAFFcount As TextBox
   Friend WithEvents ButtonNextStaff As Button
   Friend WithEvents ButtonStaffJumpF As Button
   Friend WithEvents Label19 As Label
   Friend WithEvents Label20 As Label
   Friend WithEvents Label21 As Label
   Friend WithEvents Label22 As Label
   Friend WithEvents ComboBoxQUALDATE As ComboBox
   Friend WithEvents TextBoxTYPE As TextBox
   Friend WithEvents TextBoxINSTNAME As TextBox
   Friend WithEvents ButtonQualJumpFirst As Button
   Friend WithEvents ButtonQualPrev As Button
   Friend WithEvents TextBoxQUALcount As TextBox
   Friend WithEvents ButtonQualNext As Button
   Friend WithEvents ButtonQualJumpLast As Button
   Friend WithEvents Label23 As Label
   Friend WithEvents Label24 As Label
   Friend WithEvents Label25 As Label
   Friend WithEvents Label26 As Label
   Friend WithEvents Label27 As Label
   Friend WithEvents TextBoxORGNAME As TextBox
   Friend WithEvents TextBoxWORKPOS As TextBox
   Friend WithEvents TextBoxSTARTDATE As TextBox
   Friend WithEvents TextBoxFINISHDATE As TextBox
   Friend WithEvents ButtonWorkJumpFirst As Button
   Friend WithEvents ButtonWorkPrev As Button
   Friend WithEvents TextBoxWORKcount As TextBox
   Friend WithEvents ButtonWorkNext As Button
   Friend WithEvents ButtonWorkJumpLast As Button
   Friend WithEvents ButtonNEWWork As Button
   Friend WithEvents ButtonSAVEwork As Button
   Friend WithEvents ButtonDELETEwork As Button
   Friend WithEvents ComboBoxFIELD As ComboBox
   Friend WithEvents ButtonALL As Button
   Friend WithEvents ButtonSEARCH As Button
   Friend WithEvents TextBoxVALUE As TextBox
   Friend WithEvents Label28 As Label
   Friend WithEvents Label29 As Label
   Friend WithEvents Button24 As Button
End Class
