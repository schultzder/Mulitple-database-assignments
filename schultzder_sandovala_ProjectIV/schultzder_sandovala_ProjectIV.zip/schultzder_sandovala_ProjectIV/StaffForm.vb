﻿Public Class Form1
   Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

   End Sub

   Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs)

   End Sub

   Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click

   End Sub
End Class
